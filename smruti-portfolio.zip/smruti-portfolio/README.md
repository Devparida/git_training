# Smruti Ranjan Parida — Portfolio

Static single-page portfolio. No build step, no dependencies, no framework.
Everything (fonts aside) is inlined in `index.html`, including images.

## Deploy to Vercel

### Option 1 — drag and drop (fastest, ~1 minute)
1. Go to https://vercel.com/new
2. Scroll to the bottom and choose the option to deploy a folder / "Deploy" without a Git repo
3. Drag this whole folder in
4. Vercel detects a static site automatically — no framework preset, no build command
5. Deploy

### Option 2 — GitHub, so you can update it later
```bash
cd smruti-portfolio
git init
git add .
git commit -m "Portfolio"
git branch -M main
git remote add origin https://github.com/Devparida/portfolio.git   # create this repo first
git push -u origin main
```
Then at https://vercel.com/new import the repo. Settings:
- Framework preset: **Other**
- Build command: *leave empty*
- Output directory: *leave empty* (or `.`)

Every later `git push` redeploys automatically.

### Option 3 — Vercel CLI
```bash
npm i -g vercel
cd smruti-portfolio
vercel          # preview deploy
vercel --prod   # production
```

## Custom domain
In Vercel: Project → Settings → Domains → Add. A `.vercel.app` subdomain
is assigned automatically, so a custom domain is optional.

## Editing
`index.html` is one file. Content is plain HTML inside `<section class="view">`
blocks — one per page (home, bookmyshow, ixigo, greenjeeva, ideator, about).
Navigation is hash-based and handled by the small script at the bottom.

## Notes
- Fonts load from Google Fonts; everything else is self-contained.
- The page is dark-only by design.
- Two external links point at live Lovable prototypes and one at the Idea Validator app.
